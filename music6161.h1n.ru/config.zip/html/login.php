<?
echo "
<div> Войти </div>
<div id='form_login'>
<div id='img_logotip'></div>
<form method = 'POST'>
<div> Логин </div>
<input type='text' name = 'login' class = 'phone_worker'  class = 'input_style'>
<br>
<br>
<div> Пароль </div>
<input type='password' name = 'password' class = 'input_style'>
<br><br><input type='submit' id = 'auth_user' class='button' value='Войти' name='submit_auth'>
</form>
</div>";
if(isset($_POST['login']) && isset($_POST['password']))
{
		$db_connect->login_auth($login, $password);
}


?>