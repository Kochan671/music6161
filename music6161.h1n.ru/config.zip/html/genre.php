<?
$id_range = $_SESSION['id_range'];

$db_connect -> artist_range($id_range);
?>