<?
echo "
<div> Регистрация </div>
<div id='form_login'>
<div id='img_logotip'></div>
<form method = 'POST'>
<div> Логин </div>
<input type='text' name = 'login' class = 'login'  class = 'input_style'>
<br>
<br>
<div> Пароль </div>
<input type='password' name = 'password' class = 'input_style'>
<br><br><input type='submit' id = 'reg_user' class='button' value='Зарегестрироваться'>
</form>
</div>";


if(isset($_POST['login']) && isset($_POST['password']))
{
	$db_connect -> reg_user($login, $password);
}



?>
